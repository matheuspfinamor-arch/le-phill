import { Button } from "@/components/ui/button";
import { ArrowRight, MessageCircle } from "lucide-react";
import { useState } from "react";

/**
 * LePhill Landing Page
 * Design: Moderno, corporativo, focado em conversão
 * Paleta: Fúcsia (#E91E63) e Cinza Escuro (#3a3a3a)
 * Tipografia: Playfair Display (títulos) + Poppins (corpo)
 */

export default function Home() {
  const [activeStep, setActiveStep] = useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-slate-900 border-b border-amber-600 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3 flex-shrink-0">
            <div className="text-2xl font-bold flex items-center">
              <span className="text-amber-500">Le</span>
              <span className="text-white">Phill</span>
            </div>
          </div>
          <nav className="hidden md:flex gap-6 items-center">
            <a href="#proposta" className="text-gray-200 hover:text-amber-500 transition font-medium">
              Solução
            </a>
            <a href="#beneficios" className="text-gray-200 hover:text-amber-500 transition font-medium">
              Benefícios
            </a>
            <a href="#metodo" className="text-gray-200 hover:text-amber-500 transition font-medium">
              Método
            </a>
            <a href="/faq" className="text-gray-200 hover:text-amber-500 transition font-medium">
              FAQ
            </a>
            <a href="/planos" className="text-gray-200 hover:text-amber-500 transition font-medium">
              Planos
            </a>
            <a
              href="https://wa.me/5511989118627?text=Olá, gostaria de criar um site para meu negócio."
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button className="bg-amber-600 hover:bg-amber-700 text-slate-900 font-semibold">
                Contato
              </Button>
            </a>
          </nav>
          <div className="md:hidden">
            <Button
              size="sm"
              className="bg-amber-600 hover:bg-amber-700 text-slate-900"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              Menu
            </Button>
          </div>
        </div>
        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-slate-800 border-t border-amber-600 p-4">
            <nav className="flex flex-col gap-4">
              <a
                href="#proposta"
                className="text-gray-200 hover:text-amber-500 transition font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                Solução
              </a>
              <a
                href="#beneficios"
                className="text-gray-200 hover:text-amber-500 transition font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                Benefícios
              </a>
              <a
                href="#metodo"
                className="text-gray-200 hover:text-amber-500 transition font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                Método
              </a>
              <a
                href="/faq"
                className="text-gray-200 hover:text-amber-500 transition font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                FAQ
              </a>
              <a
                href="/planos"
                className="text-gray-200 hover:text-amber-500 transition font-medium"
                onClick={() => setMobileMenuOpen(false)}
              >
                Planos
              </a>
              <a
                href="https://wa.me/5511989118627?text=Olá, gostaria de criar um site para meu negócio."
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button className="w-full bg-amber-600 hover:bg-amber-700 text-slate-900 font-semibold">
                  Contato
                </Button>
              </a>
            </nav>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden min-h-screen flex items-center bg-slate-950">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{
            backgroundImage: `url('https://d2xsxph8kpxj0f.cloudfront.net/310519663488121257/RvKytNzCaNmqpmi2LPbWGX/hero-background-fPAGqBPxoT7DNjbRyqjHXg.webp')`,
          }}
        />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32 w-full">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight animate-in fade-in duration-700">
              Transformamos as buscas do Google em <span className="text-amber-500">Clientes Reais</span> para sua Empresa Local
            </h1>
            <p className="text-lg md:text-xl text-gray-300 mb-8 leading-relaxed animate-in fade-in duration-700 delay-100">
              Sites profissionais, rápidos e focados em vendas, criados especialmente para negócios que querem dominar a região. Apareça para quem está procurando por você hoje.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 animate-in fade-in duration-700 delay-200">
              <a
              href="https://wa.me/5511989118627?text=Olá, gostaria de criar um site para meu negócio."
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button
                size="lg"
                className="bg-amber-600 hover:bg-amber-700 text-slate-900 text-lg px-8 py-6 rounded-lg font-semibold flex items-center justify-center gap-2 transition-all hover:shadow-lg w-full sm:w-auto"
              >
                Solicitar Análise Gratuita <ArrowRight className="w-5 h-5" />
              </Button>
            </a>
            </div>
          </div>
        </div>
      </section>

      {/* Proposta de Valor */}
      <section id="proposta" className="py-16 md:py-24 bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Sua Empresa Não Pode Ser Invisível no Google
            </h2>
            <p className="text-lg text-gray-300 leading-relaxed">
              Clientes já estão procurando pelo seu serviço ou produto no Google Maps. Mas se você não tem uma presença digital profissional, eles encontram seus concorrentes em vez de você. A LePhill resolve isso criando uma presença digital sólida que converte buscas em vendas reais.
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-slate-800 p-8 rounded-lg shadow-sm border border-slate-700">
              <h3 className="text-xl font-bold text-white mb-4">O Problema</h3>
              <ul className="space-y-3 text-gray-300">
                <li className="flex gap-3">
                  <span className="text-amber-500 font-bold">✕</span>
                  <span>Sem site profissional = invisibilidade online</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-amber-500 font-bold">✕</span>
                  <span>Clientes encontram concorrentes antes de você</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-amber-500 font-bold">✕</span>
                  <span>Perda de oportunidades de vendas todos os dias</span>
                </li>
              </ul>
            </div>
            <div className="bg-slate-800 p-8 rounded-lg shadow-sm border-2 border-amber-600">
              <h3 className="text-xl font-bold text-white mb-4">A Solução LePhill</h3>
              <ul className="space-y-3 text-gray-300">
                <li className="flex gap-3">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Site profissional focado em conversão</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Integração com Google Maps para fácil acesso</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Clientes encontram você e compram com facilidade</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Seção de Benefícios */}
      <section id="beneficios" className="py-16 md:py-24 bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 text-center">
            O Que Seus Clientes Ganham
          </h2>
          <p className="text-lg text-gray-300 text-center mb-12 max-w-2xl mx-auto">
            Funcionalidades reais que convertem visitantes em clientes      </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Benefício 1: WhatsApp */}
            <div className="bg-slate-800 border-2 border-slate-700 rounded-lg p-8 hover:border-amber-600 transition">
              <div className="w-16 h-16 bg-green-500 rounded-lg flex items-center justify-center mb-6">
                <span className="text-2xl" aria-label="WhatsApp" title="Botão WhatsApp Flutuante">💬</span>
              </div>
              <h3 className="text-lg font-bold text-white mb-3">Botão WhatsApp Flutuante</h3>
              <p className="text-gray-300">Contato imediato a um clique. Seus clientes podem conversar com você direto do site.</p>
            </div>

            {/* Benefício 2: Google Maps */}
            <div className="bg-slate-800 border-2 border-slate-700 rounded-lg p-8 hover:border-amber-600 transition">
              <div className="w-16 h-16 bg-red-500 rounded-lg flex items-center justify-center mb-6">
                <span className="text-2xl" aria-label="Google Maps" title="Integração Google Maps">📍</span>
              </div>
              <h3 className="text-lg font-bold text-white mb-3">Integração Google Maps</h3>
              <p className="text-gray-300">Rota fácil para sua loja física. Clientes encontram você rapidamente.</p>
            </div>

            {/* Benefício 3: Mobile */}
            <div className="bg-slate-800 border-2 border-slate-700 rounded-lg p-8 hover:border-amber-600 transition">
              <div className="w-16 h-16 bg-blue-500 rounded-lg flex items-center justify-center mb-6">
                <span className="text-2xl" aria-label="Celular" title="Design para Celular">📱</span>
              </div>
              <h3 className="text-lg font-bold text-white mb-3">Design para Celular</h3>
              <p className="text-gray-300">Site perfeito em qualquer tela. 80% dos clientes acessam pelo celular.</p>
            </div>

            {/* Benefício 4: Velocidade */}
            <div className="bg-slate-800 border-2 border-slate-700 rounded-lg p-8 hover:border-amber-600 transition">
              <div className="w-16 h-16 bg-yellow-500 rounded-lg flex items-center justify-center mb-6">
                <span className="text-2xl" aria-label="Velocidade" title="Velocidade de Carga">⚡</span>
              </div>
              <h3 className="text-lg font-bold text-white mb-3">Velocidade de Carga</h3>
              <p className="text-gray-300">O cliente não espera, ele clica e compra. Sites rápidos vendem mais.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Seção de Planos e Preços */}
      <section className="py-16 md:py-24 bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 text-center">
            Planos para Todo Tipo de Negócio
          </h2>
          <p className="text-lg text-gray-300 text-center mb-12 max-w-2xl mx-auto">
            Transparência total — sem taxas escondidas
          </p>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Plano Simples */}
            <div className="bg-slate-800 border-2 border-slate-700 rounded-lg p-8 hover:border-amber-600 transition">
              <h3 className="text-2xl font-bold text-white mb-4">Pacote Simples</h3>
              <div className="mb-6">
                <div className="text-3xl font-bold text-amber-500">R$ 500</div>
                <div className="text-sm text-gray-400 mt-1">pagamento único</div>
                <div className="text-sm text-gray-400 mt-2">+ <span className="text-white font-semibold">R$ 30/mês</span></div>
              </div>
              <ul className="space-y-3 text-sm text-gray-300">
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Até 4 páginas</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Template adaptado</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Versão mobile</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>SEO completo</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Suporte por 30 dias</span>
                </li>
              </ul>
              <div className="mt-6 p-4 bg-slate-700 rounded-lg border border-amber-600 border-opacity-30">
                <p className="text-xs text-gray-300"><strong>SEO completo incluso</strong> — meta tags, sitemap, schema markup e indexação no Google configurados</p>
              </div>
              <a
                href="https://wa.me/5511989118627?text=Olá, gostaria de contratar o plano Simples de criação de sites. Qual o próximo passo?"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-8 block"
              >
                <button className="w-full bg-amber-600 hover:bg-amber-700 text-slate-900 font-semibold py-3 rounded-lg transition">
                  Começar agora
                </button>
              </a>
            </div>

            {/* Plano Negócio */}
            <div className="bg-slate-800 border-2 border-amber-600 rounded-lg p-8 shadow-lg relative">
              <div className="absolute top-4 right-4 bg-amber-600 text-slate-900 px-3 py-1 rounded-full text-xs font-bold">
                Mais Popular
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">Pacote Negócio</h3>
              <div className="mb-6">
                <div className="text-3xl font-bold text-amber-500">R$ 800</div>
                <div className="text-sm text-gray-400 mt-1">pagamento único</div>
                <div className="text-sm text-gray-400 mt-2">+ <span className="text-white font-semibold">R$ 35/mês</span></div>
              </div>
              <ul className="space-y-3 text-sm text-gray-300">
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Até 5 páginas</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Template personalizado</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Integração WhatsApp</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Formulário de contato</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>SEO completo</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Suporte por 60 dias</span>
                </li>
              </ul>
              <div className="mt-6 p-4 bg-slate-700 rounded-lg border border-amber-600 border-opacity-30">
                <p className="text-xs text-gray-300"><strong>SEO completo incluso</strong> — meta tags, sitemap, schema markup e indexação no Google configurados</p>
              </div>
              <a
                href="https://wa.me/5511989118627?text=Olá, gostaria de contratar o plano Negócio de criação de sites. Qual o próximo passo?"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-8 block"
              >
                <button className="w-full bg-amber-600 hover:bg-amber-700 text-slate-900 font-semibold py-3 rounded-lg transition">
                  Começar agora
                </button>
              </a>
            </div>

            {/* Plano Premium */}
            <div className="bg-slate-800 border-2 border-slate-700 rounded-lg p-8 hover:border-amber-600 transition">
              <h3 className="text-2xl font-bold text-white mb-4">Pacote Premium</h3>
              <div className="mb-6">
                <div className="text-3xl font-bold text-amber-500">R$ 1.000</div>
                <div className="text-sm text-gray-400 mt-1">pagamento único</div>
                <div className="text-sm text-gray-400 mt-2">+ <span className="text-white font-semibold">R$ 40/mês</span></div>
              </div>
              <ul className="space-y-3 text-sm text-gray-300">
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Até 7 páginas</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Design 100% personalizado</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Auxílio na criação dos textos</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>SEO avançado</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Google Analytics</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Integração WhatsApp e Instagram</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>1 alteração mensal gratuita</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 font-bold">✓</span>
                  <span>Suporte prioritário por 120 dias</span>
                </li>
              </ul>
              <div className="mt-6 p-4 bg-slate-700 rounded-lg border border-amber-600 border-opacity-30">
                <p className="text-xs text-gray-300"><strong>SEO completo + Google Search Console e Google Analytics configurados</strong></p>
              </div>
              <a
                href="https://wa.me/5511989118627?text=Olá, gostaria de contratar o plano Premium de criação de sites. Qual o próximo passo?"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-8 block"
              >
                <button className="w-full bg-amber-600 hover:bg-amber-700 text-slate-900 font-semibold py-3 rounded-lg transition">
                  Começar agora
                </button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Faixa de Garantia */}
      <section className="py-8 bg-slate-800 border-y border-amber-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-lg text-white flex items-center justify-center gap-3">
            <span className="text-2xl" aria-label="Escudo de garantia" title="Garantia de satisfação">🛡️</span>
            <span><strong>Garantia de satisfação</strong> — Se você não aprovar o layout, refazemos sem custo adicional.</span>
          </p>
        </div>
      </section>

      {/* Seção de Método */}
      <section id="metodo" className="py-16 md:py-24 bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 text-center">
            Seu Novo Site em 3 Passos Simples
          </h2>
          <p className="text-lg text-gray-300 text-center mb-12 max-w-2xl mx-auto">
            Processo simples, rápido e focado em resultados
          </p>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                number: "1",
                title: "Análise",
                description: "Estudamos seu nicho, seus clientes e seus concorrentes para criar a melhor estratégia.",
                icon: "📊",
              },
              {
                number: "2",
                title: "Criação",
                description: "Desenvolvemos um site profissional focado em vendas, com design moderno e funcionalidades essenciais.",
                icon: "🎨",
              },
              {
                number: "3",
                title: "Entrega",
                description: "Seu site no ar gerando resultados. Suporte contínuo para garantir seu sucesso.",
                icon: "🚀",
              },
            ].map((step, index) => (
              <div
                key={index}
                className="relative"
              >
                <div className="p-8 rounded-lg bg-amber-600 text-slate-900 shadow-lg">
                  <div className="text-4xl font-bold mb-4" aria-label={`Passo ${step.number}: ${step.title}`} title={step.title}>{step.icon}</div>
                  <div className="text-3xl font-bold mb-4">Passo {step.number}</div>
                  <h3 className="text-xl font-bold mb-3">{step.title}</h3>
                  <p className="text-slate-900">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>



      {/* CTA Final */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-slate-950 to-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Pronto para Dominar Sua Região?
          </h2>
          <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
            Solicite uma análise gratuita do seu negócio. Vamos mostrar exatamente como você pode aparecer no Google e converter clientes.
          </p>
          <a
            href="https://wa.me/5511989118627?text=Olá, gostaria de criar um site para meu negócio."
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button
              size="lg"
              className="bg-amber-600 hover:bg-amber-700 text-slate-900 text-lg px-8 py-6 rounded-lg font-semibold"
            >
              Solicitar Análise Gratuita
            </Button>
          </a>
          <p className="text-sm text-gray-400 mt-4">
            Sem compromisso. Você só paga o restante quando aprovar o resultado.
          </p>
        </div>
      </section>

      {/* Floating WhatsApp Button */}
      <a
        href="https://wa.me/5511989118627?text=Olá, gostaria de criar um site para meu negócio."
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 bg-green-500 hover:bg-green-600 text-white rounded-full p-4 shadow-lg transition-all hover:scale-110 border-4 border-amber-600 flex items-center justify-center"
        title="Enviar mensagem via WhatsApp"
        aria-label="Botão flutuante do WhatsApp - Enviar mensagem"
      >
        <span className="text-3xl" aria-hidden="true">💬</span>
      </a>

      {/* Footer */}
      <footer className="bg-slate-950 text-gray-400 py-12 border-t border-amber-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="text-lg font-bold flex items-center">
                  <span className="text-amber-500">Le</span>
                  <span className="text-white">Phill</span>
                </div>
              </div>
              <p className="text-sm">Transformando negócios locais em presença digital poderosa.</p>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Serviços</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-amber-500 transition">Criação de Sites</a></li>
                <li><a href="#" className="hover:text-amber-500 transition">Google Maps</a></li>
                <li><a href="#" className="hover:text-amber-500 transition">Integração WhatsApp</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Empresa</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-amber-500 transition">Sobre Nós</a></li>

                <li><a href="#" className="hover:text-amber-500 transition">Contato</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Contato</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2"><span>✉️</span> <a href="mailto:le.phill101@gmail.com" className="hover:text-amber-500 transition">le.phill101@gmail.com</a></li>
                <li className="flex items-center gap-2"><span>💬</span> <a href="https://wa.me/5511989118627" target="_blank" rel="noopener noreferrer" className="hover:text-amber-500 transition">(11) 98911-8627</a></li>
              </ul>
            </div>

          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-sm">
            <p>&copy; 2026 LePhill. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
