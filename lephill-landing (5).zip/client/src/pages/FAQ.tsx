import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";

export default function FAQ() {
  const [openItems, setOpenItems] = useState<number[]>([]);

  const toggleItem = (index: number) => {
    setOpenItems((prev) =>
      prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
    );
  };

  const faqSections = [
    {
      title: "Sobre o site",
      items: [
        {
          question: "O site vai funcionar bem no celular?",
          answer:
            "Sim. Todos os nossos sites são desenvolvidos com design responsivo — se adaptam automaticamente a qualquer tela, seja celular, tablet ou computador.",
        },
        {
          question: "Consigo atualizar o conteúdo sozinho depois?",
          answer:
            "Textos e imagens simples podem ser trocados com um pouco de orientação técnica. Para mudanças maiores, oferecemos um serviço de manutenção avulso. Se você precisar atualizar com frequência, podemos conversar sobre a melhor solução.",
        },
        {
          question: "O site vai aparecer no Google?",
          answer:
            "Sim. Todos os nossos sites são entregues com SEO técnico completo configurado — meta tags, sitemap XML, schema markup e robots.txt otimizado. Isso garante que o Google consiga encontrar e indexar seu site corretamente desde o primeiro dia. No plano Premium, configuramos também o Google Search Console e o Google Analytics para você acompanhar os resultados. O posicionamento em si depende de outros fatores como a concorrência na sua área e o tempo de vida do site, mas a base técnica já estará pronta.",
        },
        {
          question: "Quantas páginas estão incluídas?",
          answer:
            "Depende do plano: o Simples inclui até 4 páginas, o Negócio até 5 e o Premium até 7. Páginas adicionais podem ser incluídas mediante orçamento.",
        },
      ],
    },
    {
      title: "Sobre o processo",
      items: [
        {
          question: "Como funciona o processo de criação?",
          answer:
            "Passamos por 4 etapas: (1) briefing — entendemos seu negócio e objetivos; (2) criação do layout para sua aprovação; (3) desenvolvimento do site; (4) revisões e entrega final.",
        },
        {
          question: "Quanto tempo leva para ficar pronto?",
          answer:
            "Em média 7 a 14 dias úteis após a aprovação do briefing e o recebimento dos materiais. Projetos Premium têm prazo acordado na contratação.",
        },
        {
          question: "Preciso ter domínio e hospedagem antes de contratar?",
          answer:
            "Não. Você pode contratar sem ter nada. Cuidamos de tudo ou te orientamos passo a passo na aquisição — como preferir.",
        },
        {
          question: "Vocês cuidam do domínio e da hospedagem ou sou eu?",
          answer:
            "Oferecemos as duas opções. Podemos gerenciar tudo por você (já incluso na mensalidade) ou configurar na sua conta, caso prefira ter o controle direto.",
        },
        {
          question: "Quantas rodadas de revisão estão incluídas?",
          answer:
            "Estão incluídas 2 rodadas de revisão após a apresentação do layout. Revisões adicionais podem ser solicitadas mediante orçamento.",
        },
      ],
    },
    {
      title: "Conteúdo e design",
      items: [
        {
          question: "Eu preciso fornecer os textos e imagens ou vocês criam?",
          answer:
            "Pedimos que você forneça as informações principais sobre o negócio. A partir disso, organizamos e redigimos os textos. Para imagens, usamos banco de imagens gratuito ou fotos suas — nos planos Premium, o auxílio na criação de textos já está incluso.",
        },
        {
          question: "Posso pedir um design personalizado ou são templates prontos?",
          answer:
            "Nos planos Negócio e Premium, o design é totalmente personalizado para o seu negócio. No plano Simples, utilizamos um template adaptado à sua identidade visual.",
        },
        {
          question: "Consigo ver exemplos de sites que já fizeram?",
          answer:
            "Sim! Temos um portfólio com projetos anteriores. Entre em contato pelo WhatsApp e te enviamos exemplos do tipo de negócio mais próximo ao seu.",
        },
      ],
    },
    {
      title: "Suporte e manutenção",
      items: [
        {
          question: "O que acontece se o site cair ou tiver algum problema?",
          answer:
            "Se o problema for relacionado ao nosso trabalho, corrigimos sem custo adicional. Problemas de hospedagem são resolvidos por nós caso você esteja no plano com hospedagem gerenciada.",
        },
        {
          question: "Vocês oferecem suporte após a entrega?",
          answer:
            "Sim. O suporte gratuito varia por plano: 30 dias no Simples, 60 dias no Negócio e 120 dias no Premium. Após esse período, o suporte continua disponível por chamados avulsos.",
        },
        {
          question: "Se eu quiser alterar algo depois, como funciona?",
          answer:
            "Basta nos chamar. Alterações pequenas têm valor fixo por chamado e alterações maiores são orçadas conforme o escopo. Clientes Premium têm 1 alteração mensal gratuita incluída.",
        },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-slate-900 border-b border-amber-600 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <a href="/" className="text-2xl font-bold flex items-center">
            <span className="text-amber-500">Le</span>
            <span className="text-white">Phill</span>
          </a>
          <a href="/">
            <Button className="bg-amber-600 hover:bg-amber-700 text-slate-900 font-semibold">
              Voltar
            </Button>
          </a>
        </div>
      </header>

      {/* FAQ Content */}
      <section className="py-16 md:py-24 bg-slate-950">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 text-center">
            Perguntas Frequentes
          </h1>
          <p className="text-lg text-gray-300 text-center mb-12">
            Respondemos as dúvidas mais comuns antes de você perguntar
          </p>

          {faqSections.map((section, sectionIndex) => (
            <div key={sectionIndex} className="mb-12">
              <h2 className="text-2xl font-bold text-amber-500 mb-6">
                {section.title}
              </h2>

              <div className="space-y-4">
                {section.items.map((item, itemIndex) => {
                  const globalIndex = faqSections
                    .slice(0, sectionIndex)
                    .reduce((sum, s) => sum + s.items.length, 0) + itemIndex;

                  return (
                    <div
                      key={globalIndex}
                      className="bg-slate-800 border border-slate-700 rounded-lg overflow-hidden"
                    >
                      <button
                        onClick={() => toggleItem(globalIndex)}
                        className="w-full px-6 py-4 flex items-center justify-between hover:bg-slate-700 transition text-left"
                      >
                        <span className="font-semibold text-white">
                          {item.question}
                        </span>
                        <ChevronDown
                          className={`w-5 h-5 text-amber-500 transition-transform ${
                            openItems.includes(globalIndex) ? "rotate-180" : ""
                          }`}
                        />
                      </button>

                      {openItems.includes(globalIndex) && (
                        <div className="px-6 py-4 bg-slate-700 border-t border-slate-600">
                          <p className="text-gray-300">{item.answer}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}

          <div className="mt-12 text-center">
            <p className="text-gray-300 mb-6">
              Ainda tem dúvidas? Fale com a gente!
            </p>
            <a
              href="https://wa.me/5511989118627?text=Olá, gostaria de criar um site para meu negócio."
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button className="bg-amber-600 hover:bg-amber-700 text-slate-900 font-semibold px-8 py-3">
                Conversar no WhatsApp
              </Button>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
