import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

export default function Planos() {
  const plans = [
    {
      name: "Simples",
      price: "R$ 500",
      monthly: "R$ 30/mês",
      description: "Para negócios que querem dar o primeiro passo no digital",
      badge: "🌱",
      features: [
        "Até 4 páginas",
        "Template adaptado ao seu negócio",
        "Conteúdo fornecido pelo cliente",
        "Versão mobile incluída",
        "SEO básico configurado",
        "Suporte por 30 dias",
      ],
    },
    {
      name: "Negócio",
      price: "R$ 800",
      monthly: "R$ 35/mês",
      description: "Para que seu negócio decole de vez",
      badge: "🚀",
      popular: true,
      features: [
        "Até 5 páginas",
        "Template personalizado para sua marca",
        "Conteúdo fornecido pelo cliente",
        "Versão mobile incluída",
        "SEO básico configurado",
        "Integração com WhatsApp",
        "Formulário de contato",
        "Suporte por 60 dias",
      ],
    },
    {
      name: "Premium",
      price: "R$ 1000",
      monthly: "R$ 40/mês",
      description: "Para que seu negócio domine seu mercado",
      badge: "👑",
      features: [
        "Até 7 páginas",
        "Design 100% personalizado",
        "Auxílio na criação dos textos",
        "Imagens de banco incluídas",
        "SEO avançado + Google Search Console",
        "Google Analytics configurado",
        "Integração com WhatsApp e Instagram",
        "1 alteração mensal gratuita",
        "Suporte prioritário por 120 dias",
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-slate-900 border-b border-amber-600 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <a href="/" className="text-2xl font-bold flex items-center">
            <span className="text-amber-500">Le</span>
            <span className="text-white">Phill</span>
          </a>
          <a href="/">
            <Button className="bg-amber-600 hover:bg-amber-700 text-slate-900 font-semibold">
              Voltar
            </Button>
          </a>
        </div>
      </header>

      {/* Planos Content */}
      <section className="py-16 md:py-24 bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 text-center">
            O plano certo para o seu negócio
          </h1>
          <p className="text-lg text-gray-300 text-center mb-12">
            Sites profissionais entregues com qualidade, rapidez e suporte real. Escolha o plano ideal para você.
          </p>

          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <div
                key={index}
                className={`relative rounded-lg p-8 border-2 transition-all ${
                  plan.popular
                    ? "bg-slate-800 border-amber-600 shadow-xl md:scale-105"
                    : "bg-slate-800 border-slate-700 hover:border-amber-600"
                }`}
              >
                {plan.popular && (
                  <div className="absolute top-4 right-4 bg-amber-600 text-slate-900 px-3 py-1 rounded-full text-sm font-bold">
                    Mais popular
                  </div>
                )}

                <div className="text-4xl mb-4">{plan.badge}</div>
                <h3 className="text-2xl font-bold text-white mb-2">
                  {plan.name}
                </h3>
                <p className="text-gray-400 mb-6 text-sm italic">
                  {plan.description}
                </p>

                <div className="mb-6 pb-6 border-b border-slate-700">
                  <div className="text-4xl font-bold text-amber-500">
                    {plan.price}
                  </div>
                  <div className="text-sm text-gray-400 mt-2">pagamento único</div>
                  <div className="text-sm text-gray-400 mt-2">
                    + <span className="font-semibold text-white">{plan.monthly}</span> (hospedagem + domínio + suporte)
                  </div>
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>

                <a
                  href={`https://wa.me/5511989118627?text=Olá, gostaria de contratar o plano ${plan.name} de criação de sites. Qual o próximo passo?`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button className="w-full bg-amber-600 hover:bg-amber-700 text-slate-900 font-semibold py-3">
                    Começar agora
                  </Button>
                </a>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <p className="text-gray-300 mb-6">
              Dúvidas? Fale com a gente pelo WhatsApp — respondemos em minutos.
            </p>
            <a
              href="https://wa.me/5511989118627?text=Olá, gostaria de criar um site para meu negócio."
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button className="bg-amber-600 hover:bg-amber-700 text-slate-900 font-semibold px-8 py-3">
                Conversar no WhatsApp
              </Button>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
